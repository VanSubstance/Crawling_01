<?php 
                $test = 1;
                echo "echo 되는지 확인<br/>";
                echo "변수값 출력 확인: $test <br/>";
                $conn = mysql_connect('localhost', 'root', '123456');
                echo "connect 활성화<br/>";
                ?>