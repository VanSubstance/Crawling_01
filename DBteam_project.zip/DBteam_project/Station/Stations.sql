SET DEFINE OFF;
insert into mysql.STATIONS (STATION_NAME, RATE) values ('Gundae', '4.400000');
insert into mysql.STATIONS (STATION_NAME, RATE) values ('Chunho', '3.700000');
insert into mysql.STATIONS (STATION_NAME, RATE) values ('Yeouido', '4.100000');
