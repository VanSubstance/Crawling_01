var i = 0;
for (i=0; i<=10; i++) {
    document.write("Hello World!");
    document.write("<br>");
}