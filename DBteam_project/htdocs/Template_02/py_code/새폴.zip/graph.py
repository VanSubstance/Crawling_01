#-*-coding: utf-8-*-
import csv, codecs

def graph(name):
    count=[0,0,0,0,0,0]
    file = open('part\\c1={}\\000000_0'.format(name), 'r', encoding='utf-8')
    read = csv.reader(file, delimiter="\n")
    for cell in read:
        cell=cell[0].split(",")
        if cell[0][:-1] != 'Erro':
            if int(cell[0][:-1]) <6:
                count[int(cell[0][:-1])]+=1
    return count

